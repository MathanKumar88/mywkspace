package com.example.service;
 
public class MessageService {
 
    public String getMessage() {
        return "Hello World!";
    }
}