package com.mathan.gradle;
 
 

public class RandomEmailGenerator {

	public String generate() {
		return "feedback@yoursite.com";
	}

}