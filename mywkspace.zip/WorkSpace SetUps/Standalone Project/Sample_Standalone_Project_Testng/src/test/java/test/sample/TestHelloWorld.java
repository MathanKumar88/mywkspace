package com.test.sample;


import org.testng.Assert;
import org.testng.annotations.Test;
import com.mathan.gradle.RandomEmailGenerator;

public class TestHelloWorld {

	@Test()
	public void testEmailGenerator() {

		RandomEmailGenerator obj = new RandomEmailGenerator();
		String email = obj.generate();

		Assert.assertNotNull(email);
		Assert.assertEquals(email, "feedback@yoursite.com");
		//System.out.println("testEmailGenerator...");

	}
	
	@Test(expectedExceptions = ArithmeticException.class)
	public void divisionWithException() {
		int i = 1 / 0;
	}

}