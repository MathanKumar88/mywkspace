package com.mathan.gradle;
 
public class MessageService {
 
    public String getMessage() {
        return "Hello World!";
    }
}