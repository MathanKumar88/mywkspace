::::::Standalone Project without libraries::::::

To run this project after build, execute the following command from project home directory

java -cp "build\compileLib\log4j-1.2.17.jar;build\libs\Sample-Jar-Project-1.0.jar" com.mathan.gradle.HelloWorld