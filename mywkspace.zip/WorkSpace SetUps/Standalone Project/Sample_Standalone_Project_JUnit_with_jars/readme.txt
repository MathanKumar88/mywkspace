::::::Standalone Project with libraries::::::

To run this project after build, execute the following command from project home directory

java -jar build\libs\Sample-Jar-Project-with-lib-1.0.jar